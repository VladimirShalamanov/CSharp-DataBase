﻿namespace ProductShop;

using AutoMapper;
using Data;
using Newtonsoft.Json;
using DTOs.Import;
using Models;
using System.Net.Http.Json;
using Microsoft.EntityFrameworkCore;

public class StartUp
{
    public static void Main()
    {
        ProductShopContext context = new ProductShopContext();
        //string inputJson = File.ReadAllText(@"../../../Datasets/categories-products.json");

        string res = GetProductsInRange(context);
        Console.WriteLine(res);
    }

    // 01
    public static string ImportUsers(ProductShopContext context, string inputJson)
    {
        IMapper mapper = CreateMapper();

        var userDtos = JsonConvert.DeserializeObject<ImportUserDto[]>(inputJson);

        ICollection<User> validUsers = new HashSet<User>();

        foreach (var u in userDtos!)
        {
            User user = mapper.Map<User>(u);
            validUsers.Add(user);
        }

        context.Users.AddRange(validUsers);
        context.SaveChanges();

        return $"Successfully imported {validUsers.Count}";
    }

    // 02
    public static string ImportProducts(ProductShopContext context, string inputJson)
    {
        IMapper mapper = CreateMapper();

        var productDtos = JsonConvert.DeserializeObject<ImportProductDto[]>(inputJson);

        var products = mapper.Map<Product[]>(productDtos);

        context.Products.AddRange(products);
        context.SaveChanges();

        return $"Successfully imported {products.Length}";
    }

    // 03
    public static string ImportCategories(ProductShopContext context, string inputJson)
    {
        IMapper mapper = CreateMapper();

        var categoryDtos =
            JsonConvert.DeserializeObject<ImportCategoryGto[]>(inputJson);

        ICollection<Category> validCategories = new HashSet<Category>();

        foreach (var cDto in categoryDtos!)
        {
            if (!string.IsNullOrEmpty(cDto.Name))
            {
                Category category = mapper.Map<Category>(cDto);
                validCategories.Add(category);
            }
        }

        context.Categories.AddRange(validCategories);
        context.SaveChanges();

        return $"Successfully imported {validCategories.Count}";
    }

    // 04
    public static string ImportCategoryProducts(ProductShopContext context, string inputJson)
    {
        IMapper mapper = CreateMapper();

        ImportCategoryProductDto[] cpDtos =
            JsonConvert.DeserializeObject<ImportCategoryProductDto[]>(inputJson);

        ICollection<CategoryProduct> validEntries = new HashSet<CategoryProduct>();

        foreach (ImportCategoryProductDto cp in cpDtos!)
        {
            if (!context.Categories.Any(c => c.Id == cp.CategoryId) ||
                !context.Products.Any(p => p.Id == cp.ProductId))
            {
                continue;
            }
            CategoryProduct catPro = mapper.Map<CategoryProduct>(cp);
            validEntries.Add(catPro);
        }

        context.CategoriesProducts.AddRange(validEntries);
        context.SaveChanges();

        return $"Successfully imported {validEntries.Count}";
    }

    // 05
    public static string GetProductsInRange(ProductShopContext context)
    {
        var products = context.Products
            .Where(p => p.Price >= 500 && p.Price <= 1000)
            .OrderBy(p => p.Price)
            .Select(p => new
            {
                name = p.Name,
                price = p.Price,
                seller = p.Seller.FirstName + " " + p.Seller.LastName
            })
            .AsNoTracking()
            .ToArray();

        return JsonConvert.SerializeObject(products, Formatting.Indented);
    }

    private static IMapper CreateMapper()
    {
        return new Mapper(new MapperConfiguration(cfg =>
        {
            cfg.AddProfile<ProductShopProfile>();
        }));
    }
}