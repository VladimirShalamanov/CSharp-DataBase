﻿namespace ProductShop;

using AutoMapper;
using Data;
using Newtonsoft.Json;
using DTOs.Import;
using Models;
using System.Net.Http.Json;

public class StartUp
{
    public static void Main()
    {
        ProductShopContext context = new ProductShopContext();
        string inputJson = File.ReadAllText(@"../../../Datasets/categories.json");

        string res = ImportCategories(context, inputJson);
        Console.WriteLine(res);
    }

    // 01
    public static string ImportUsers(ProductShopContext context, string inputJson)
    {
        IMapper mapper = CreateMapper();

        var userDtos = JsonConvert.DeserializeObject<ImportUserDto[]>(inputJson);

        ICollection<User> validUsers = new HashSet<User>();

        foreach (var u in userDtos!)
        {
            User user = mapper.Map<User>(u);
            validUsers.Add(user);
        }

        context.Users.AddRange(validUsers);
        context.SaveChanges();

        return $"Successfully imported {validUsers.Count}";
    }

    // 02
    public static string ImportProducts(ProductShopContext context, string inputJson)
    {
        IMapper mapper = CreateMapper();

        var productDtos = JsonConvert.DeserializeObject<ImportProductDto[]>(inputJson);

        var products = mapper.Map<Product[]>(productDtos);

        context.Products.AddRange(products);
        context.SaveChanges();

        return $"Successfully imported {products.Length}";
    }

    // 03
    public static string ImportCategories(ProductShopContext context, string inputJson)
    {
        IMapper mapper = CreateMapper();

        var categoryDtos =
            JsonConvert.DeserializeObject<ImportCategoryGto[]>(inputJson);

        ICollection<Category> validCategories = new HashSet<Category>();

        foreach (var cDto in categoryDtos!)
        {
            if (!string.IsNullOrEmpty(cDto.Name))
            {
                Category category = mapper.Map<Category>(cDto);
                validCategories.Add(category);
            }
        }

        context.Categories.AddRange(validCategories);
        context.SaveChanges();

        return $"Successfully imported {validCategories.Count}";
    }

    private static IMapper CreateMapper()
    {
        return new Mapper(new MapperConfiguration(cfg =>
        {
            cfg.AddProfile<ProductShopProfile>();
        }));
    }
}