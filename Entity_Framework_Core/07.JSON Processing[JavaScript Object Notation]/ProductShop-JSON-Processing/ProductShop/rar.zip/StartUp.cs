﻿namespace ProductShop;

using AutoMapper;
using Data;
using Newtonsoft.Json;
using DTOs.Import;
using Models;
using System.Net.Http.Json;

public class StartUp
{
    public static void Main()
    {
        ProductShopContext context = new ProductShopContext();
        string inputJson = File.ReadAllText(@"../../../Datasets/users.json");

        string res = ImportUsers(context, inputJson);
        Console.WriteLine(res);
    }

    public static string ImportUsers(ProductShopContext context, string inputJson)
    {
        IMapper mapper = new Mapper(new MapperConfiguration(cfg =>
        {
            cfg.AddProfile<ProductShopProfile>();
        }));

        var userDtos = JsonConvert.DeserializeObject<ImportUserDto[]>(inputJson);

        ICollection<User> validUsers = new HashSet<User>();

        foreach (var u in userDtos)
        {
            User user = mapper.Map<User>(u);
            validUsers.Add(user);
        }

        context.Users.AddRange(validUsers);
        context.SaveChanges();

        return $"Successfully imported {validUsers.Count}";
    }
}