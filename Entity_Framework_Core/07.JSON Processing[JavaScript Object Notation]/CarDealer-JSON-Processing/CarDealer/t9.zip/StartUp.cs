﻿namespace CarDealer;

using AutoMapper;
using Data;
using DTOs.Import;
using Models;
using Newtonsoft.Json;
using System.IO;

public class StartUp
{
    public static void Main()
    {
        CarDealerContext context = new CarDealerContext();

        string inputJson = File.ReadAllText(@"../../../Datasets/suppliers.json");

        string res = ImportSuppliers(context, inputJson);

        Console.WriteLine(res);
    }

    // 01
    public static string ImportSuppliers(CarDealerContext context, string inputJson)
    {
        IMapper mapper = CreateMapper();

        var suppliersDtos = JsonConvert.DeserializeObject<ImpoortSupplierDto[]>(inputJson);

        ICollection<Supplier> suppliers = mapper.Map<Supplier[]>(suppliersDtos);

        context.Suppliers.AddRange(suppliers);
        context.SaveChanges();

        return $"Successfully imported {suppliers.Count}.";
    }

    // 02

    private static IMapper CreateMapper()
    {
        return new Mapper(new MapperConfiguration(cfg =>
        {
            cfg.AddProfile<CarDealerProfile>();
        }));
    }
}