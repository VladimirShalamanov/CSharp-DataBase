﻿namespace CarDealer.DTOs.Export;

public class TotalSaleByCustomer
{
    public string fullName { get; set; }

    public int boughtCars { get; set; }

    public decimal spentMoney { get; set; }
}
