﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Artillery;Integrated Security=True;Encrypt=False";
    }
}
