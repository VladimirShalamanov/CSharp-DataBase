﻿namespace Artillery.DataProcessor.ImportDto
{
    public class GunWithCountryDto
    {
        public int Id { get; set; }
    }
}
