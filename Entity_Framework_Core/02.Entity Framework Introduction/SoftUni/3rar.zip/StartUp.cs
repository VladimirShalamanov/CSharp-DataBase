﻿using SoftUni.Data;
using SoftUni.Models;
using System.Text;

namespace SoftUni;

public class StartUp
{
    static void Main(string[] args)
    {
        SoftUniContext context = new SoftUniContext();

        string res = GetEmployeesFullInformation(context);

        Console.WriteLine(res);
    }

    public static string GetEmployeesFullInformation(SoftUniContext context)
    {
        var sb = new StringBuilder();

        Employee[] eployees = context.Employees
            .OrderBy(e => e.EmployeeId)
            .ToArray();

        foreach (Employee e in eployees) 
        {
            sb.AppendLine($"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}");
        }

        return sb.ToString().TrimEnd();
    }
}